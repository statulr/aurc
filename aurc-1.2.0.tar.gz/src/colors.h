#ifndef AURC_COLORS_H
#define AURC_COLORS_H

// ANSI escape codes for colors
#define RED "\033[1;31m"
#define GREEN "\033[1;32m"
#define YELLOW "\033[1;33m"
#define RESET "\033[0m"

#endif // AURC_COLORS_H